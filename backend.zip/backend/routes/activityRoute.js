const express = require("express");
const { addActivity } = require("../controllers/activityController");
const { isAuthenticatedUser, authorizeRoles } = require("../middleware/auth");

const router = express.Router();

router.route("/add").post(addActivity)

module.exports = router;