const Activity = require('../models/activityModel');
const ErrorHander = require('../utils/errorhander');
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const sendToken = require('../utils/jwtToken');

exports.addActivity = catchAsyncErrors( async (req, res, next) => {
        const { name,type,whether,description } = req.body;
        const activity = await Activity.create({name,type,whether,description}); 
        sendToken(activity, 201, res);
});


exports.reccomendActivity = catchAsyncErrors( async (req,res,next) => {
    
});  