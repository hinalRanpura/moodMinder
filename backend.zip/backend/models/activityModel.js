const mongoose = require("mongoose");
const jwt = require("jsonwebtoken");

const activitySchema = mongoose.Schema({
    name: {
        type: String,
        required: [true,'Please Enter Activity Name'],
        maxLength: [50,'Activity name can not exeed 50 characters'],
        minLength: [4,"Activity name Should have more than 4 characters"],
    },
    type: {
        type: String,
        required: [true,'Please Enter Activity type'],
    }, 
    description: {
        type: String,
        required: [true,'Please Enter Activity description'],
    }, 
    whether: {
        type: String,
        required: [true,'Please Enter Particular whether for Activity'],
    },
});
  


//JWT Token
activitySchema.methods.getJWTToken = function (){
    return jwt.sign({id:this._id},process.env.JWT_SECRET,{
        expiresIn:process.env.JWT_EXPIRE,

    });
};


module.exports = mongoose.model("Activity", activitySchema);